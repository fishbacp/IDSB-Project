import numpy as np
from scipy.signal import chirp
import matplotlib.pyplot as plt
from stockwell import st

from mne.time_frequency import tfr_array_stockwell as stockwell


################ MNE #######################

def next_power_of_2(x):  
    return 1 if x == 0 else 2**(x - 1).bit_length()

fs=1000
L= 5000 #signal length in ms.

t=np.linspace(0,10,L)

w=chirp(t, f0=12.5, f1=2.5, t1=10, method='linear')

fmin = 0  # Hz
fmax = 25  # Hz

# spectrum shows intensity from 12.5 going down to 2.5 over10 seconds

'''
df = 1./(t[-1]-t[0])  # sampling step in frequency domain (Hz)

print('samp freq: '+str(df))
print(t[-1])

fmin_samples = int(fmin/df)

print('fmin: '+str(fmin_samples))

fmax_samples = int(fmax/df)
print(fmax_samples)

start_time = time.process_time()

stock = st.st(w, fmin_samples, fmax_samples)

print(np.around(stock[0:10,0:10],4))

extent = (t[0], t[-1], fmin, fmax)

fig, ax = plt.subplots(2, 1, sharex=True)
ax[0].plot(t, w)
ax[0].set(ylabel='amplitude')
ax[1].imshow(np.abs(stock), origin='lower', extent=extent)
ax[1].axis('tight')
ax[1].set(xlabel='time (s)', ylabel='frequency (Hz)')
plt.show()

conn_win_value=int(L/fs)
no=int(fs*conn_win_value)
n_fft=2*no

n_fft=next_power_of_2(len(w))

print(n_fft)
print(fs/n_fft)  #This is the frequency resolution

print(2**12)

n_fft=L


#w1=np.expand_dims(w,axis=0)
#w1=np.expand_dims(w1,axis=0)

w1=np.expand_dims(w,axis=(0,1))

# w was originally a signal of length 5000, we add two dimensions, one for epoch and one for channel
# print(w1.shape)


S, itc, freqs=stockwell(w1,fs,fmin=fmin,fmax=fmax)
# returns 1-by-num_freqs -by - num_times
# S: stockwell transform itself in form 1 -by- num_freq -by- num_times: 1-by-410-by-5001
# itc: None
#freqs: 410 equally spaced frequencies of increments of  from fmin=25 to fmax=2.5
print(S.shape)
print(freqs)
S=np.squeeze(S,axis=0) # Now S is num_freq -by- num_times; 410-by-5001
print(S.shape)
print(np.around(S[0:2,0:2],8))

delta_freq = np.mean(np.diff(freqs))
print(delta_freq)
print(fs / n_fft)

# print(freqs)

'''

from mne.time_frequency import tfr_array_stockwell as stockwell_transform
import warnings
warnings.filterwarnings("ignore")

def stockwell_transform(signal,fmin,fmax):
    signal_epoch=np.expand_dims(signal,axis=(0,1))
    S, itc, freqs=stockwell(signal_epoch,fs,fmin=fmin,fmax=fmax)
    S=np.squeeze(S,axis=0)
    return S

fmin = 0  # Hz
fmax = 25  # Hz

fs=1000
L= 5000 #signal length in ms.

t=np.linspace(0,10,L)
signal=chirp(t, f0=12.5, f1=2.5, t1=10, method='linear')

S=stockwell_transform(signal,fmin,fmax)

print(S.shape)

fig, ax = plt.subplots(2, 1, sharex=True)
extent = (t[0], t[-1], fmin, fmax)
ax[0].plot(t, signal)
ax[0].set(ylabel='amplitude')
ax[1].imshow(np.abs(S), origin='lower', extent=extent)
ax[1].axis('tight')
ax[1].set(xlabel='time (s)', ylabel='frequency (Hz)')
plt.show()








    
    





'''
extent = (t[0], t[-1], fmin, fmax)

fig, ax = plt.subplots(2, 1, sharex=True)
ax[0].plot(t, w)
ax[0].set(ylabel='amplitude')
ax[1].imshow(np.abs(S), origin='lower', extent=extent)
ax[1].axis('tight')
ax[1].set(xlabel='time (s)', ylabel='frequency (Hz)')
plt.show()

# spectrum shows intensity from 12.5 going down to 2.5 over 10 seconds

'''
