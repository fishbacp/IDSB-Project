import numpy as np
from scipy.linalg import toeplitz

from scipy.signal import chirp
import matplotlib.pyplot as plt

########### EQSIG ############################

##########  TAKEN FROM https://eqsig.readthedocs.io/en/latest/_modules/eqsig/stockwell.html
def generate_gaussian(n_d2):
    """create a gaussian distribution"""
    f_half = np.arange(0, n_d2 + 1, 1) / (2 * n_d2)
    f = np.concatenate((f_half, np.flipud(-f_half[1:-1])))
    p = 2 * np.pi * np.outer(f, 1. / f_half[1:])
    return np.exp(-p ** 2 / 2).transpose()

def transform(acc, interp=False):
    '''
    Performs a Stockwell transform on an array

    Assumes m = 1, p = 1

    :param acc: array_like
    :return:
    '''

    acc_db = acc
    n_d2 = int(len(acc) / 2)
    n_factor = 2 * n_d2
    gaussian = generate_gaussian(n_d2)

    fa = np.fft.fft(acc_db, n_factor)
    diag_con = toeplitz(np.conj(fa[:n_d2 + 1]), fa)
    diag_con = diag_con[1:n_d2 + 1, :]  # first line is zero frequency

    stock = np.flipud(np.fft.ifft(diag_con * gaussian, axis=1))

    return stock

fs=10000
L=1000
t=np.linspace(0,int(fs/L),int(fs/2))
#t = np.arange(0, L/1000,1/fs)
print(t)
w = chirp(t, f0=12.5, f1=2.5, t1=10, method='linear')

stock=transform(w)

# Shape is num_samples -by- num_freqs, where num_freqs increases from 0 to fs/2 in increments of one. 

print(stock.shape)

fmin=0
fmax=25
extent = (t[0], t[-1], fmin, fmax)

print(stock.shape)
print(np.around(stock[0:2,0:2],4))

fig, ax = plt.subplots(2, 1, sharex=False)
ax[0].plot(t, w)
ax[0].set(ylabel='amplitude')
ax[1].imshow(np.abs(stock), origin='lower',extent=extent)
ax[1].axis('tight')
ax[1].set(xlabel='samples', ylabel='frequency')
plt.show()

# spectrum shows intensity INCREASING 10 seconds
