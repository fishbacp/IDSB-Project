import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from matplotlib.animation import FuncAnimation
from mpl_toolkits.axes_grid1 import make_axes_locatable
import mpl_toolkits
import matplotlib.ticker as ticker


import matplotlib.widgets
from matplotlib.widgets import Slider
from matplotlib.figure import Figure

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from tkinter import Tk,TOP,BOTH,Toplevel

import matplotlib
matplotlib.use('Qt5Agg')

################ SEE

class Player(FuncAnimation):
    def __init__(self, fig, func, frames=None, init_func=None, fargs=None,save_count=None, mini=0, maxi=100, pos=(0.125, 0.92), **kwargs):
        self.i = 0
        self.min=mini
        self.max=maxi
        self.runs = True
        self.forwards = True

        self.fig = fig
        self.func = func
        self.setup(pos)
        FuncAnimation.__init__(self,self.fig, self.func, frames=self.play(),
                                           init_func=init_func, fargs=fargs,
                                           save_count=save_count,interval=500, **kwargs )

    def play(self):
        while self.runs:
            self.i = self.i+self.forwards-(not self.forwards)
            if self.i > self.min and self.i < self.max:
                yield self.i
            else:
                self.stop()
                yield self.i

    def start(self):
        if self.i==self.max:
            self.i=0
        self.runs=True
        self.event_source.start()

    def stop(self, event=None):
        self.runs = False
        self.event_source.stop()

    def forward(self, event=None):
        self.forwards = True
        self.start()

    def backward(self, event=None):
        self.forwards = False
        self.start()

    def oneforward(self, event=None):
        self.forwards = True
        self.onestep()
    def onebackward(self, event=None):
        self.forwards = False
        self.onestep()


    def onestep(self):
        if self.i > self.min and self.i < self.max:
            self.i = self.i+self.forwards-(not self.forwards)
        elif self.i == self.min and self.forwards:
            self.i+=1
        elif self.i == self.max and not self.forwards:
            self.i-=1
        self.func(self.i)
        self.fig.canvas.draw_idle()



    def setup(self, pos):
        playerax = self.fig.add_axes([pos[0],pos[1], 0.22, 0.04])
        divider = mpl_toolkits.axes_grid1.make_axes_locatable(playerax)
        bax = divider.append_axes("right", size="80%", pad=0.05)
        sax = divider.append_axes("right", size="80%", pad=0.05)
        fax = divider.append_axes("right", size="80%", pad=0.05)
        ofax = divider.append_axes("right", size="100%", pad=0.05)
        self.button_oneback = matplotlib.widgets.Button(playerax , label=u'$\u29CF$')
        self.button_back = matplotlib.widgets.Button(bax, label=u'$\u25C0$')
        self.button_stop = matplotlib.widgets.Button(sax, label=u'$\u25A0$')
        self.button_forward = matplotlib.widgets.Button(fax, label=u'$\u25B6$')
        self.button_oneforward = matplotlib.widgets.Button(ofax, label=u'$\u29D0$')
        self.button_oneback.on_clicked(self.onebackward)
        self.button_back.on_clicked(self.backward)
        self.button_stop.on_clicked(self.stop)
        self.button_forward.on_clicked(self.forward)
        self.button_oneforward.on_clicked(self.oneforward)


###################################################################
#########  HEATPLOT ANIMATION ###############################

def heatplot_animation(root,channels,M_list,conn_win_value,title='Connectivity Matrices Animation'):
    num_times=len(M_list)
    fig=Figure()
    plot_window = Toplevel(bg="lightgray")
    plot_window.geometry('1400x900')
    plot_window.wm_title(title)
    plot_window.attributes('-topmost', 'true')

    canvas = FigureCanvasTkAgg(fig, master=plot_window)
    canvas.draw()
    canvas.get_tk_widget().pack(side=TOP,fill=BOTH,expand=1)


    def update_matrix(i):
        # clear current axes
        ax.cla()
        ax.set_xticks(range(len(channels)))
        ax.set_xticklabels(channels,fontsize=10,rotation=45)
        ax.set_yticklabels(channels,fontsize=10,rotation=45)
        ax.set_yticks(range(len(channels)))
        sns.heatmap(ax = ax, data = M_list[i], cmap = "coolwarm", cbar_ax = cbar_ax,vmin=0,vmax=1,xticklabels=channels, yticklabels=channels)
        ax.set_yticklabels(channels,fontsize=10,rotation=45)
        fig.suptitle('Frame: '+str(np.round(i*conn_win_value,3)), fontsize=12)


    ax=fig.add_subplot(111)
    # set up axes labels OUTSIDE update function so we don't need to re-create for
    # each frame.

    #ax.set_xticks(range(len(channels)))
    #ax.set_xticklabels(channels,fontsize=10)
    #ax.set_yticks(range(len(channels)))
    #ax.set_yticklabels(channels,fontsize=10)

    # create heatmap color bar
    divider = make_axes_locatable(ax)
    cbar_ax = divider.append_axes("right", size="5%", pad=0.05)

    # Create animation with buttons as described at URL above.
    ani = Player(fig, update_matrix, maxi=num_times)



### EXAMPLE ANIMATION

'''
root=Tk()
root.title('Main Window')
root.geometry('1000x1000')
conn_win_value=.5

M_list=[np.random.rand(8,8) for i in range(50)]
channels=['a','b','c','d','e','f','g','h']
heatplot_animation(root,channels,M_list,conn_win_value)
root.mainloop()
'''

###################################################################
#########  HEATPLOT AND CENTRALITY ANIMATIONS COMBINED ###############################

def heatplot_centrality_animation_combined(root,channels,M_list,bar_list,conn_win_value,title='Functional Connectivities and Centralities'):
    num_times=len(M_list)-1*0
    fig, ax = plt.subplots(2)

    plot_window = Toplevel(root,bg="lightgray")
    plot_window.geometry('1400x900')
    plot_window.wm_title(title)
    plot_window.attributes('-topmost', 'true')

    canvas = FigureCanvasTkAgg(fig, master=plot_window)
    canvas.draw()
    canvas.get_tk_widget().pack(side=TOP,fill=BOTH,expand=1)


    # need to reverse order of labels on y-axis below; place tickmarks at center for both axis

    tick_locs=[.5+i for i in range(len(channels))]

    #ax[0].set_xticks(range(len(channels)))
    ax[0].set_xticks(tick_locs)
    ax[0].set_xticklabels(channels,fontsize=10)

    #ax[0].set_yticks(range(len(channels)))
    ax[0].set_yticks(tick_locs)
    ax[0].set_yticklabels(channels,fontsize=10)
    ax[0].invert_yaxis()

    ax[1].set_xticks(tick_locs)
    ax[1].set_xticklabels(channels,fontsize=10)



    #ax[1].xaxis.set_major_formatter(ticker.NullFormatter())
    #ax[1].xaxis.set_minor_locator(ticker.FixedLocator([.5,1.5,2.5,3.5]))

    #heatmap=ax[0].imshow(M_list[0],vmin=0, vmax=1, cmap='coolwarm', aspect='auto')

    #ax0_divider = make_axes_locatable(ax[0])
    #cax0 = ax0_divider.append_axes('right', size='7%', pad='2%')
    #cb = fig.colorbar(heatmap, cax=cax0, orientation='vertical')

    #ax[1].cla()
    #ax[1].bar(channels,bar_list[0])
    #ax[1].set_ylim(0, 1)

    '''
    plot_window = Toplevel(root,bg="lightgray")
    plot_window.geometry('1400x900')
    plot_window.wm_title(title)
    plot_window.attributes('-topmost', 'true')


    canvas = FigureCanvasTkAgg(fig, master=plot_window)
    canvas.draw()
    canvas.get_tk_widget().pack(side=TOP,fill=BOTH,expand=1)
    '''

    def update_graph(i):
        ax[0].cla

        heatmap=ax[0].imshow(M_list[i-1*1],vmin=0, vmax=1, cmap='coolwarm', aspect='auto')

        ax[0].set_xticks(range(len(channels)))
        ax[0].set_xticklabels(channels,fontsize=10,)
        ax[0].set_yticks(range(len(channels)))
        ax[0].set_yticklabels(channels,fontsize=10,rotation=0)

        ax0_divider = make_axes_locatable(ax[0])
        cax0 = ax0_divider.append_axes('right', size='7%', pad='2%')
        cb = fig.colorbar(heatmap, cax=cax0, orientation='vertical')

        ax[1].cla()
        ax[1].bar(channels,bar_list[i-1*1])
        ax[1].set_ylim(0, 1)

        fig.suptitle('Time: '+str(np.round((i-1*0)*conn_win_value,3))+ ' sec', fontsize=12)

    ani = Player(fig, update_graph, maxi=num_times)



### EXAMPLE ANIMATION

'''
import random
root=Tk()
root.title('Main Window')
root.geometry('1000x1000')

channels=['a','b','c','d','e','f','g','h']
Nc=len(channels)
Nt=10
M_list=[np.random.rand(Nc,Nc) for i in range(Nt)]
bar_list=[[random.uniform(0,1) for i in range(Nc)] for t in range(Nt)]
conn_win_value=.5
heatplot_centrality_animation_combined(root,channels,M_list,bar_list,conn_win_value,title='Functional Connectivities and Centralities')

root.mainloop()
'''

