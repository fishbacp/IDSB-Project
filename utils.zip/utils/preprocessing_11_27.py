import numpy as np
import mne as mn
import warnings


from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

import matplotlib.backends.backend_tkagg as tkagg
import matplotlib.ticker as ticker

from matplotlib import pyplot as plt
from matplotlib.figure import Figure

from tkinter import Tk, Frame,Label, Button, Entry,Label, Checkbutton,BooleanVar,filedialog,StringVar,messagebox,ttk,DoubleVar,Frame,LEFT,TOP,RIGHT,BOTTOM,BOTH,Menu,Toplevel,PhotoImage
from tkinter import font as tkFont
from tkinter.ttk import Progressbar

from functools import partial

from mne.preprocessing import annotate_muscle_zscore,ICA
from mne import create_info
from mne.io import RawArray



def remove_line_noise(eeg):
    # remove line noise from ALL  channels
    freqs_powerline = [60 , 120, 180, 240]
    freqs=[freq for freq in freqs_powerline if freq<=eeg.fs/2]
    raw_notch = eeg.raw.copy().notch_filter(freqs=freqs)
    eeg.raw=raw_notch
    # eeg.raw.info['bads']=eeg.raw.info["ch_names"]
    eeg.canvas_frame.destroy()
    eeg.plot_canvas()


def find_channel_subset_annotations(raw,fs,raw_temp_channels):

    eog_events = mn.preprocessing.find_eog_events(raw,ch_name=raw_temp_channels)
    onsets = eog_events[:, 0] / fs - 0.25
    # Assume blinks have duration .5 sec.
    durations = [0.5] * len(eog_events)
    descriptions = ['B'] * len(eog_events)
    blink_annot = mn.Annotations(onsets, durations, descriptions)  #ch_names should be

    threshold_muscle = 4
    all_annot=blink_annot

    if fs/2>110:
        filter_freq=[110,min(140,fs/2)]
        annot_muscle, scores_muscle = annotate_muscle_zscore(raw,threshold=threshold_muscle, min_length_good=0.2,filter_freq=filter_freq)  #use 110, 140
        onsets=[annot_muscle[i]['onset'] for i in range(len(annot_muscle))]
        durations=[annot_muscle[i]['duration'] for i in range(len(annot_muscle))]
        descriptions = ['M'] * len(annot_muscle)
        muscle_annot = mn.Annotations(onsets, durations, descriptions)
        all_annot=blink_annot.__add__(muscle_annot)

    return all_annot


def repair_artifacts(root,eeg,threshold=.7):
   bads=eeg.fig.mne.info['bads']
   channels=eeg.raw.info['ch_names']
   to_drop=list(set(channels).intersection(set(bads)))
   raw=eeg.raw.drop_channels(to_drop)
   channels=raw.info["ch_names"]
   fs=int(raw.info['sfreq'])

   print('CHANNELS TO REPAIR:')
   print(channels)

   raw_filt = raw.copy().load_data().filter(l_freq=1., h_freq=None)
   print('RAW FILTERED $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$')
   ica = ICA(method='fastica',n_components=.999999, random_state=5,max_iter="auto")
   ica.fit(raw_filt,picks=channels)

   print('ICA FIT $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$')

   #with warnings.catch_warnings(record=True) as w:
   ica.fit(raw_filt,picks=channels)
   '''
    print('LENGTH OF W &&&&&&&&&&&&&&&&: '+str(len(w)))
    if len(w) > 0:
        messagebox.showwarning("Warning","Unstable results. Remove bad channels.")
        return
    else:
    '''
   eog_idx, eog_scores=ica.find_bads_eog(raw,ch_name=channels,measure='correlation',threshold=.9,reject_by_annotation=False)
   #    ecg_idx, ecg_scores=ica.find_bads_ecg(raw,ch_name=channels[0],measure='correlation',threshold=threshold)
   excludes = sorted(set(eog_idx))
   ica.exclude =excludes
   print('EXCLUDES **************************')
   print(excludes)
   includes=[i for i in range(ica.unmixing_matrix_.shape[0])]

   print(ica.n_components_)
   print(np.round(ica.mixing_matrix_,2))

   raw_repaired=ica.apply(raw) #,include=includes,exclude=excludes)
   return raw_repaired
