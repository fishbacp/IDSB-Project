import numpy as np
import mne as mn
import warnings


from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

import matplotlib.backends.backend_tkagg as tkagg
import matplotlib.ticker as ticker


from matplotlib import pyplot as plt
from matplotlib.figure import Figure
import matplotlib
matplotlib.use('Qt5Agg',force=True)

from tkinter import Tk, Frame,Label, Button, Entry,Label, Checkbutton,BooleanVar,filedialog,StringVar,messagebox,ttk,DoubleVar,Frame,LEFT,TOP,RIGHT,BOTTOM,BOTH,Menu,Toplevel,PhotoImage
from tkinter import font as tkFont
from tkinter.ttk import Progressbar

from functools import partial

from mne.preprocessing import annotate_muscle_zscore,ICA
from mne import create_info
from mne.io import RawArray

from utils.general import plot_selected



def remove_line_noise(eeg):
    # remove line noise from ALL  channels
    freqs_powerline = [60 , 120, 180, 240]
    freqs=[freq for freq in freqs_powerline if freq<=eeg.fs/2]
    raw_notch = eeg.raw.copy().notch_filter(freqs=freqs)
    eeg.raw=raw_notch
    # eeg.raw.info['bads']=eeg.raw.info["ch_names"]
    eeg.canvas_frame.destroy()
    eeg.plot_canvas()


def find_channel_subset_annotations(raw,fs,channels):

    # determines and marks eog artifacts for all raw channels, good and bad
    # eog_events is an array
    eog_events = mn.preprocessing.find_eog_events(raw,ch_name=channels[0],reject_by_annotation=False)
    #eog_events has size num_events by 3. Each row consists of start index, zero, 998
    eog_onsets = eog_events[:, 0] / fs - .1 # now in seconds
    # Assume blinks have duration of .25 to .4 sec. We use .3 sec
    durations = [.3] * len(eog_events)
    descriptions = ['B'] * len(eog_events)

    eog_annot = mn.Annotations(eog_onsets, durations, descriptions)

    ecg_events,ch_ecg,average_pulse=mn.preprocessing.find_ecg_events(raw,ch_name=channels[0],reject_by_annotation=False)
    #eog_events has size num_events by 3. Each row consists of start index, zero, 998

    ecg_onsets = ecg_events[:, 0] / fs - .05 # now in seconds
    # Assume artifacts have duration of .1 sec
    durations = [.1] * len(ecg_events)
    descriptions = ['M'] * len(ecg_events)

    ecg_annot = mn.Annotations(ecg_onsets, durations, descriptions)

    all_annot=eog_annot.__add__(ecg_annot)

    threshold_muscle = 4

    ''' won't work for synthetic signals below
    if fs/2>110:
        print(fs)
        filter_freq=[110,min(140,fs/2)]
        annot_muscle, scores_muscle = annotate_muscle_zscore(raw,ch_type='eeg',threshold=threshold_muscle, min_length_good=.1,filter_freq=filter_freq)  #use 110, 140
        print(scores_muscle)
        onsets=[annot_muscle[i]['onset'] for i in range(len(annot_muscle))]
        durations=[annot_muscle[i]['duration'] for i in range(len(annot_muscle))]
        descriptions = ['M'] * len(annot_muscle)
        muscle_annot = mn.Annotations(onsets, durations, descriptions)
        all_annot=blink_annot.__add__(muscle_annot)

    '''

    return all_annot

'''

def repair_artifacts_old(root,eeg,threshold=.9):
    # repairs artifacts for all channels, good and bad, which haven't been dropped via plot selec
   # eeg.canvas_frame.destroy()
   fs=eeg.fs
   raw_temp=eeg.raw.copy()
   bads=eeg.fig.mne.info['bads']
   channels=eeg.fig.mne.info['ch_names']
   to_drop=list(set(channels).intersection(set(bads)))
   eeg.raw.drop_channels(to_drop)
   channels=eeg.raw.info['ch_names']
   #eeg.plot_canvas(annotations=False)

   raw=eeg.raw

   raw_filt = raw.copy().load_data().filter(l_freq=1., h_freq=None)
   ica = ICA(method='fastica',n_components=.999999, random_state=5,max_iter="auto")
   ica.fit(raw_filt,picks=channels)

   eog_idx, eog_scores=ica.find_bads_eog(raw_filt,ch_name=channels,measure='correlation',threshold=threshold,reject_by_annotation=False)
   #ecg_idx, ecg_scores=ica.find_bads_ecg(raw_filt,ch_name=channels[0],measure='correlation',threshold=threshold)
   #idx=set(eog_idx).union(set(ecg_idx))
   idx=eog_idx
   excludes=sorted(idx)
   ica.exclude =excludes
   print('excludes*****************************************')
   print(excludes)
   if len(excludes)>0:
       print(str(len(excludes))+ ' components dropped')
       raw_repaired=ica.apply(raw_filt.copy(),exclude=excludes) #,include=includes,exclude=excludes) #,include=includes,exclude=excludes)
       data,times=raw_filt[:,:]
       data_repaired,times_new=raw_repaired[:,:]
       eeg.raw=raw_repaired
   else:
       messagebox.showwarning('Warning',message='No repairs could be performed. Consider visual rejection or alternate means. ')

   eeg.annotations=None
   eeg.canvas_frame.destroy()
   eeg.plot_canvas(annotations=False)
   return
   '''

def repair_artifacts(root,eeg,threshold=.9):
    #eeg.canvas_frame.destroy()
    plot_selected(root,eeg,annotations=False)

    ''' raw selection is that portion of eeg.raw, from tmin to tmax we wish to repair,
    we repair this to obtain raw_repaired. Then eeg.raw is the concatenation of eeg.raw.crop(0 tmin),
    raw_repaired, eeg.raw.crop(tmax,end)'''

    raw_selection = eeg.raw.copy().crop(tmin=eeg.start_time, tmax=eeg.end_time)
    print(raw_selection)

    channels=eeg.raw.info['ch_names']
    raw_filt = raw_selection.copy().load_data().filter(l_freq=1., h_freq=None)
    ica = ICA(method='fastica',n_components=len(channels))
    ica.fit(raw_filt,picks=channels,decim=1)

    ica_components_window = Toplevel()
    ica_components_window.configure(bg='lightgrey')
    ica_components_window.geometry('1400x900')

    ica_components_window.wm_title("Latent Sources")
    ica_components_window.attributes('-topmost', 'true')
    fig=ica.plot_sources(raw_filt, block=True,show_scrollbars=True,title='Latent Sources')

    canvas = FigureCanvasTkAgg(fig, master=ica_components_window)
    canvas.draw()
    canvas.get_tk_widget().pack(side=TOP,fill=BOTH,expand=1)

    raw_repaired=ica.apply(raw_filt.copy(),exclude=ica.exclude)

    raw_beginning.append[raw_repaired,raw_ending]


    eeg.raw=raw_beginning   #raw_repaired

    eeg.annotations=None
    eeg.canvas_frame.destroy()
    plot_selected(root,eeg,annotations=False)
    #eeg.plot_canvas()

    return
