import numpy as np
import mne as mn

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

import matplotlib.backends.backend_tkagg as tkagg
import matplotlib.ticker as ticker

from matplotlib import pyplot as plt
from matplotlib.figure import Figure

from tkinter import Tk, Frame,Label, Button, Entry,Label, Checkbutton,BooleanVar,filedialog,StringVar,messagebox,ttk,DoubleVar,Frame,LEFT,TOP,RIGHT,BOTTOM,BOTH,Menu,Toplevel,PhotoImage
from tkinter import font as tkFont
from tkinter.ttk import Progressbar

from utils.general import plot_selected,replot


from mne.preprocessing import annotate_muscle_zscore
from mne import create_info
from mne.io import RawArray

from functools import partial

import os
import re

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)



############ DATA VALIDATION TO ENSURE ONLY ACCEPTABLE INPUT

def validate(string):
    regex = re.compile(r"(\+|\-)?[0-9.]*$")
    result = regex.match(string)
    return (string == ""
            or (string.count('+') <= 0
                and string.count('-') <= 0
                and string.count('.')<=1
                and result is not None
                and result.group(0) != ""))

def on_validate(P):
    return validate(P)

############## PLOT OPTIONS #########################
###################################################

########## UPDATE PLOT OPTIONS
def update_plot_options(root,eeg):
    error=False

    ###### CHECK FOR VALID INPUT
    if len(time_length_value.get())==0 or float(time_length_value.get())<0: ### ENSURE VALID PLOT WINDOW DURATION
            messagebox.showerror("Error","Enter valid plot window length!")
            error=True

    if len(plot_start_value.get() )==0 or float(plot_start_value.get())<0:
        messagebox.showerror('Error','Enter valid start time')
        error=True

    if 1*float(plot_start_value.get())*eeg.fs+float(time_length_value.get())*eeg.fs >len(eeg.raw):
        messagebox.showerror('Error','Enter valid window!')
        error=True

    if not error:
        eeg.plot_start=float(plot_start_value.get())   ## This is entered in minutes, so change to seconds!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        eeg.plot_duration=min(1*float(time_length_value.get()), len(eeg.raw)/eeg.fs-eeg.plot_start  )
        eeg.plot_options_changed=True

        eeg.plot_options_window.destroy()
        #replot(root,eeg)
        eeg.canvas_frame.destroy()
        eeg.plot_canvas()



################ SET UP PLOT OPTIONS WINDOW
def plot_options(root,eeg):
    global time_length_value,plot_start_value

    ### PLOT WINDOW START
    plot_start_label=ttk.Label(eeg.plot_options_window, text="Start of EEG Plot (0 sec. default)")
    plot_start_label.pack()
    plot_start_value = Entry(eeg.plot_options_window ,width=5,validate="key",bg='white')

    if eeg.plot_options_changed==True:
        plot_start_value.insert(0,str(eeg.plot_start))
    else:
        plot_start_value.insert( 0,'0')

    vcmd = (plot_start_value.register(on_validate), '%P')
    plot_start_value.config(validatecommand=vcmd)
    plot_start_value.pack(side=TOP)

    ### PLOT WINDOW LENGTH
    time_length_label=ttk.Label(eeg.plot_options_window, text="Plot Window Length  (5 sec default)")
    time_length_label.pack()
    time_length_value = Entry(eeg.plot_options_window ,width=5,validate="key",bg='white')

    if eeg.plot_options_changed==True:
        time_length_value.insert(0,str(eeg.plot_duration))
    else:
        time_length_value.insert( 0,'5')

    vcmd = (time_length_value.register(on_validate), '%P')
    time_length_value.config(validatecommand=vcmd)
    time_length_value.pack(side=TOP)

#############  PLOT OPTIONS RESET
def plot_options_reset(root,eeg):
    plot_start_value.delete(0,'end')
    plot_start_value.insert(0,'0')

    time_length_value.delete(0,'end')
    time_length_value.insert(0,'5')



############## CONNECTIVITY OPTIONS #########################
###################################################

########## UPDATE CONN OPTIONS
def update_conn_options(root,eeg):

    error=False

    ###### CHECK FOR VALID INPUT

    time_length_value=int(1*float(end_time_value.get())-1*float(start_time_value.get()))

    #if len(time_length_value.get())==0 or float(time_length_value.get())<0: ### ENSURE VALID PLOT WINDOW DURATION
    if time_length_value==0 or time_length_value<0:
            messagebox.showerror("Error","Enter a valid plot window length!")
            error=True
    print(time_length_value)

    #if int(float(time_length_value.get())*eeg.fs)>len(eeg.raw):
    if time_length_value*eeg.fs>len(eeg.raw):
            messagebox.showerror("Error","Window length too long!")
            error=True


    if int(float(end_time_value.get())*eeg.fs)>len(eeg.raw):
        messagebox.showerror("Error","Ending time larger than recording length!")
        error=True

    if float(end_time_value.get())<= float(start_time_value.get()):
        messagebox.showerror("Error","Start time must be less than end time!")
        error=True

    # Check that conn_win_value is in required range
    if float(conn_win_value.get())<.1 or float(conn_win_value.get())>2:
            messagebox.showerror("Error","Window length must be between .1 and 2 sec!")
            error=True

    if float(fmin_value.get())>float(fmax_value.get()):
            messagebox.showerror("Error","Upper frequency must be greater than lower!")
            error=True

    if float(fmax_value.get())>eeg.fs/2:
            messagebox.showerror("Error","Upper frequency cannot exceed Nyquist (" +str(eeg.fs/2)+ ")")
            error=True

    if float(fmin_value.get())<=0:
            messagebox.showerror("Error","Frequencies must be positive!")
            error=True

    if float(conns_percentile_value.get())<=0 or float(conns_percentile_value.get())>=1:
            messagebox.showerror('Error','Percentile cutoff must be strictly positive and less than one!')
            error=True

    if not error:
        eeg.start_time=1*float(start_time_value.get())  # MEASURED IN SECONDS
        eeg.end_time=1*float(end_time_value.get())


        eeg.conn_win_value=float(conn_win_value.get())
        eeg.fmin_value=int(float(fmin_value.get()))
        eeg.fmax_value=int(float(fmax_value.get()))
        #eeg.include_centrality=include_centrality.get()
        eeg.conns_percentile=float(conns_percentile_value.get())

        eeg.conn_options_changed=True

        eeg.plot_start=eeg.start_time
        eeg.plot_duration=eeg.end_time-eeg.start_time
        eeg.conn_options_window.destroy()

        eeg.canvas_frame.destroy()
        eeg.plot_canvas()

        #replot(root,eeg)



################ SET UP CONN OPTIONS WINDOW

def conn_options(root,eeg):
    global start_time_value,end_time_value,conn_win_value,fmin_value,fmax_value,include_centrality,conns_percentile_value

    ## start time
    start_time_label=ttk.Label(eeg.conn_options_window, text="Start Time in sec (default: beginning)")
    start_time_label.pack()
    start_time_value = Entry(eeg.conn_options_window ,width=5,validate="key",bg='white')

    if eeg.conn_options_changed==True:
        start_time_value.insert(0,str(np.round(eeg.start_time/1,2)))  # START TIME IN MINUTES; eeg.start_time IN SECONDS
    else:
        start_time_value.insert( 0,'0')

    vcmd = (start_time_value.register(on_validate), '%P')
    start_time_value.config(validatecommand=vcmd)
    start_time_value.pack(side=TOP)

    ##  end time
    end_time_label=ttk.Label(eeg.conn_options_window, text="End Time in sec (default: end of recording)")
    end_time_label.pack()
    end_time_value = Entry(eeg.conn_options_window ,width=5,validate="key",bg='white')


    if eeg.conn_options_changed==True:
        end_time_value.insert(0,str(np.round(eeg.end_time/1,2)))
    else:
        #end_time_value.insert( 0,str((len(eeg.raw)/eeg.fs)))
        end_time_value.insert(0,str(np.round(len(eeg.raw)/(1*eeg.fs),2)))

    vcmd = (end_time_value.register(on_validate), '%P')
    end_time_value.config(validatecommand=vcmd)
    end_time_value.pack(side=TOP)


    ##  window size
    conn_win_label=ttk.Label(eeg.conn_options_window, text="Window length (.1 to 2 sec. default: .5)")
    conn_win_label.pack()
    conn_win_value = Entry(eeg.conn_options_window ,width=5,validate="key",bg='white')


    if eeg.conn_options_changed==True:
        conn_win_value.insert(0,str(eeg.conn_win_value))
    else:
        conn_win_value.insert( 0,'.5')

    vcmd = (conn_win_value.register(on_validate), '%P')
    conn_win_value.config(validatecommand=vcmd)
    conn_win_value.pack(side=TOP)

    ##  lower frequency
    fmin_label=ttk.Label(eeg.conn_options_window, text="Lower frequency (default: 5  Hz.)")
    fmin_label.pack()
    fmin_value = Entry(eeg.conn_options_window ,width=5,validate="key",bg='white')

    if eeg.conn_options_changed==True:
        fmin_value.insert(0,str(eeg.fmin_value))
    else:
        fmin_value.insert( 0,'5')

    vcmd = (fmin_value.register(on_validate), '%P')
    fmin_value.config(validatecommand=vcmd)
    fmin_value.pack(side=TOP)

    ##  upper frequency
    fmax_label=ttk.Label(eeg.conn_options_window, text="Upper frequency (default: 30  Hz.)")
    fmax_label.pack()
    fmax_value = Entry(eeg.conn_options_window ,width=5,validate="key",bg='white')

    if eeg.conn_options_changed==True:
        fmax_value.insert(0,str(eeg.fmax_value))
    else:
        fmax_value.insert( 0,'30')

    vcmd = (fmax_value.register(on_validate), '%P')
    fmax_value.config(validatecommand=vcmd)
    fmax_value.pack(side=TOP)

    ##  connections percentile cutoff for swadtf
    conns_percentile_label=ttk.Label(eeg.conn_options_window, text="Connections Percentile Cutoff (between 0 and 1, default: .99)")
    conns_percentile_label.pack()
    conns_percentile_value = Entry(eeg.conn_options_window ,width=5,validate="key",bg='white')

    if eeg.conn_options_changed==True:
        conns_percentile_value.insert(0,str(eeg.conns_percentile))
    else:
        conns_percentile_value.insert( 0,'.99')

    vcmd = (conns_percentile_value.register(on_validate), '%P')
    conns_percentile_value.config(validatecommand=vcmd)
    conns_percentile_value.pack(side=TOP)



############# RESET CONN OPTIONS TO DEFAULTS

def conn_options_reset(root,eeg):

    start_time_value.delete(0,'end')
    start_time_value.insert(0,'0')

    end_time_value.delete(0,'end')
    #end_time_value.insert( 0,str((len(eeg.raw)/eeg.fs)))
    end_time_value.insert(0,str(np.round(len(eeg.raw)/(1*eeg.fs),2)))

    eeg.start_time=0
    eeg.end_time=(len(eeg.raw_orig)/eeg.fs)


    conn_win_value.delete(0,'end')
    conn_win_value.insert( 0,'.5')

    fmin_value.delete(0,'end')
    fmin_value.insert( 0,'5')

    fmax_value.delete(0,'end')
    fmax_value.insert( 0,'30')

    #conns_percentile.delete(0,'end')
    #conns_percentile_value.insert( 0,'.9')

    eeg.conn_options_changed=False


    # Indicate whether to include centrality
    '''
    include_centrality=BooleanVar()
    if eeg.conn_options_changed==True:
        include_centrality.set(eeg.include_centrality)
    else:
        include_centrality.set(False)

    include_centrality_button = ttk.Checkbutton(master= eeg.conn_options_window, text="Include centrality scores", var= include_centrality)
    include_centrality_button.pack(side=TOP)
    '''

############## HFO OPTIONS #########################
###################################################

########## UPDATE HFO OPTIONS

def update_hfo_options(root,eeg):

    error=False

    ###### CHECK FOR VALID INPUT

    time_length_value=int(float(end_time_value.get())-float(start_time_value.get()))  # IN MINUTES
    time_length_value_float=float(end_time_value.get())-float(start_time_value.get())

    #if len(time_length_value.get())==0 or float(time_length_value.get())<0: ### ENSURE VALID PLOT WINDOW DURATION
    if  time_length_value_float==0 or time_length_value_float<0:
        messagebox.showerror("Error","Enter valid plot window length!")
        error=True

    #if int(float(time_length_value.get())*eeg.fs)>len(eeg.raw):
    if 1*time_length_value*eeg.fs>len(eeg.raw) :
        messagebox.showerror("Error","Window length exceeds recording length!")
        error=True

    #if int(float(end_time_value.get())*eeg.fs)>len(eeg.raw):
    #   messagebox.showerror("Error","Ending time larger than recording length!")
    #    return

    if float(end_time_value.get())<= float(start_time_value.get()):
        messagebox.showerror("Error","Start time must be less than end time!")
        error=True

    if not(num_win_value.get().isdigit()) or float(num_win_value.get())<1:
        messagebox.showerror('Error','Number of windows must be a positive integer')
        error=True

    if not(num_win_value.get().isdigit()):
        messagebox.showerror('Error','Number of windows must be an integer. No decimals!')
        error=True

    if len(num_win_value.get())==0 or float(num_win_value.get())<1:
        messagebox.showerror("Error","Number of windows must be at least one!")
        error=True

    if len(win_size_value.get())==0 or float(win_size_value.get())<0:
        messagebox.showerror("Error","Subwindow size must be nonnegative")
        error=True

    #if int(num_win_value.get())*int(float(win_size_value.get()))*eeg.fs>len(eeg.raw) and  include_channel_time.get():
         #messagebox.showerror("Error","Product of subwindow size and number of subwindows exceeds recording length!")
         #return


    ## win_size_value in seconds; divide by 60 to get minutes
    if windowed.get() and int(num_win_value.get())*int(float(win_size_value.get())/1)> time_length_value:  #and include_channel_time.get():
         messagebox.showerror("Error","Product of subwindow size and number of subwindows exceeds end time minus start time!")
         error=True

    ## if start/end times changed and num window=1, insert the time length into win_size
    if windowed.get() and int(num_win_value.get())==1:  #and include_channel_time.get():
            win_size_value.delete(0,'end')
            win_size_value.insert( 0,str(time_length_value))


    #if int(num_win_value.get())*int(float(win_size_value.get()))*eeg.fs>int(float(end_time_value.get())-float(start_time_value.get()))*eeg.fs:  #and include_channel_time.get():
    #     messagebox.showerror("Error","Product of subwindow size and number of subwindows exceeds end time minus start time!")
    #     return

   # if eeg.include_channel_time and not(eeg.windowed):
         #messagebox.showerror("Error","To include time-frequency values for each channel, select windowed checkbox ")
         #return

    if include_channel_time.get() and not windowed.get():
        messagebox.showerror("Error","To include time-frequency values for each channel, select windowed checkbox ")
        error=True

    if not error:   ####################### PERHAPS JUST SET eeg PROPERTIES TO DEFAULTS IF ERROR IS TRUE
        if not windowed.get() and float(num_win_value.get())==1:
            eeg.win_size=1*(float(end_time_value.get())-float(start_time_value.get()))
        else:
            eeg.win_size=float(win_size_value.get())


        eeg.start_time=1*float(start_time_value.get())  # MEASURED IN SECONDS
        eeg.end_time=1*float(end_time_value.get())
        eeg.num_win=int(float(num_win_value.get()))
        # eeg.win_size=float(win_size_value.get())
        eeg.windowed=windowed.get()
        eeg.include_channel_time=include_channel_time.get()

        eeg.hfo_options_changed=True

        eeg.plot_start=eeg.start_time
        eeg.plot_duration=eeg.end_time-eeg.start_time
        eeg.hfo_options_window.destroy()

        #replot(root,eeg)
        eeg.canvas_frame.destroy()
        eeg.plot_canvas()


################ SET UP HFO OPTIONS WINDOW

def hfo_options(root,eeg):
    global time_length_value,num_win_value,win_size_value, include_channel_time,start_time_value,end_time_value,windowed

    ## start time
    start_time_label=ttk.Label(eeg.hfo_options_window, text="Start Time in sec (default: beginning)")
    start_time_label.pack()
    start_time_value = Entry(eeg.hfo_options_window ,width=5,validate="key",bg='white')

    if eeg.hfo_options_changed==True:
        #start_time_value.insert(0,str(eeg.start_time))
        start_time_value.insert(0,str(np.round(eeg.start_time/1,2)))  # START TIME IN SECONDS
    else:
        start_time_value.insert( 0,'0')

    vcmd = (start_time_value.register(on_validate), '%P')
    start_time_value.config(validatecommand=vcmd)
    start_time_value.pack(side=TOP)

    ##  end time
    end_time_label=ttk.Label(eeg.hfo_options_window, text="End Time in sec (default: end of recording)")
    end_time_label.pack()
    end_time_value = Entry(eeg.hfo_options_window ,width=5,validate="key",bg='white')


    if eeg.hfo_options_changed==True:
        #end_time_value.insert(0,str(eeg.end_time))
        end_time_value.insert(0,str(np.round(eeg.end_time/1,2)))  # START TIME IN SECONDS

    else:
        #end_time_value.insert( 0,str((len(eeg.raw)/eeg.fs)))
        end_time_value.insert(0,str(np.round(len(eeg.raw)/(1*eeg.fs),2)))

    vcmd = (end_time_value.register(on_validate), '%P')
    end_time_value.config(validatecommand=vcmd)
    end_time_value.pack(side=TOP)


    # Indicate whether to use WINDOWED
    windowed=BooleanVar()
    if eeg.hfo_options_changed==True:
        windowed.set(eeg.windowed)
    else:
        windowed.set(False)

    windowed_button = ttk.Checkbutton(master= eeg.hfo_options_window, text="Use randomly chosen, nonoverlapping windows (Hilbert-Stockwell only)", var= windowed)
    windowed_button.pack(side=TOP)

    ## indicate number of windows:

    num_win_label=ttk.Label(eeg.hfo_options_window, text="Number of subwindows (default=1)")
    num_win_label.pack()
    num_win_value = Entry(eeg.hfo_options_window ,width=5,validate="key",bg='white')

    if eeg.hfo_options_changed==True:
        num_win_value.insert(0,str(eeg.num_win))
    else:
        num_win_value.insert( 0,'1')

    vcmd = (end_time_value.register(on_validate), '%P')
    num_win_value.config(validatecommand=vcmd)
    num_win_value.pack(side=TOP)


    ## indicate subwindow length

    win_size_label=ttk.Label(eeg.hfo_options_window, text="Subwindow size in sec. (default: entire recording)")
    win_size_label.pack()
    win_size_value = Entry(eeg.hfo_options_window ,width=5,validate="key",bg='white')

    if eeg.hfo_options_changed==True:
        win_size_value.insert(0,str(eeg.win_size))
    else:
        win_size_value.insert( 0,str((len(eeg.raw)/eeg.fs)))

    vcmd = (win_size_value.register(on_validate), '%P')
    win_size_value.config(validatecommand=vcmd)
    win_size_value.pack(side=TOP)


    # Indicate whether to include channel-time MATRIX
    include_channel_time=BooleanVar()
    if eeg.hfo_options_changed==True:
        include_channel_time.set(eeg.include_channel_time)
    else:
        include_channel_time.set(False)

    include_channel_time_button = ttk.Checkbutton(master= eeg.hfo_options_window, text="Include time-frequency values for each channel. (HS only)", var= include_channel_time)
    include_channel_time_button.pack(side=TOP)


########## RESET HFO OPTIONS TO DEFAULTS
def hfo_options_reset(root,eeg):
    start_time_value.delete(0,'end')
    start_time_value.insert( 0,'0')

    end_time_value.delete(0,'end')
    #end_time_value.insert( 0,str((len(eeg.raw)/eeg.fs)))
    end_time_value.insert(0,str(np.round(len(eeg.raw)/(1*eeg.fs),2)))

    windowed.set(False)

    num_win_value.delete(0,'end')
    num_win_value.insert( 0,'1')

    win_size_value.delete(0,'end')
    win_size_value.insert( 0,str((len(eeg.raw)/eeg.fs)))

    eeg.hfo_options_changed=False
