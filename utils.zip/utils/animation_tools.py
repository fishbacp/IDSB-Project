import numpy as np
import matplotlib.pyplot as plt


from matplotlib.animation import FuncAnimation
from mpl_toolkits.axes_grid1 import make_axes_locatable
import mpl_toolkits
import matplotlib.ticker as ticker


import matplotlib.widgets
from matplotlib.widgets import Slider
from matplotlib.figure import Figure

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from tkinter import Tk,TOP,BOTH,Toplevel,Frame

import matplotlib
# matplotlib.use('Qt5Agg',force=True)
matplotlib.use('TkAgg',force=True)

plt.rcParams["figure.figsize"] = [18,10]


################ AUXILLIARY FUNCTION TO DETERMINE CHANNEL LABEL PLOT SIZE DEPENDENDING
################## NUMBER OF CHANNELS BEING SELECTED FOR PLOT

def font_size(channels):
    if len(channels)>40:
        return 4
    else:
        if len(channels)>=30:
            return 6
        else:
            if len(channels)>=15:
                return 10
            else:
                return 12

################ AUXILLIARY FUNCTION TO LIST ALL CHANNEL PAIRS FROM LIST OF CHANNELS,
################## FOR EXAMPLE IF Channels=['a','b','c'], OUTPUT IS ['ab','ac','bc']
###############  USEFUL FOR VIEWING COHERENCE CONFIGUREATION MATRIX

def list_channel_pairs(channels):
    Nc=len(channels)
    channel_pairs=[]
    for i in range(Nc):
        for j in np.arange(i+1,Nc,1):
            channel_pairs.append(channels[i]+'-'+channels[j])
    return channel_pairs


############# COMBINED ANIMATION USING MATPLOTLIB ALONE ############################

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable
from matplotlib.widgets import Slider

def heatplot_barplot_animation2(labels,M_list,bar_list,win_value):
    num_times=len(M_list)

    fig, ax = plt.subplots(2)
    plt.subplots_adjust(left=None, bottom=.2, right=None, top=.9, wspace=.2, hspace=.2)

    ax_time=fig.add_axes([0.25, 0.1, 0.65, 0.03])
    s_time = Slider(ax_time, 'Time', 0, num_times, valinit=0,valstep=1)

    def update_graph(val):
        i= s_time.val
        ax[0].cla()
        heatmap=ax[0].imshow(M_list[i-1*1],vmin=0, vmax=1, cmap='coolwarm', aspect='auto')

        ax[0].set_xticks(range(len(labels)))
        ax[0].set_xticklabels(labels,fontsize=10,)
        ax[0].set_yticks(range(len(labels)))
        ax[0].set_yticklabels(labels,fontsize=10)

        ax0_divider = make_axes_locatable(ax[0])
        cax0 = ax0_divider.append_axes('right', size='7%', pad='2%')
        cb = fig.colorbar(heatmap, cax=cax0, orientation='vertical')

        ax[1].cla()
        ax[1].bar(labels,bar_list[i-1])
        ax[1].set_ylim(0, 1)

        plt.show()

    s_time.on_changed(update_graph)
    s_time.set_val(0)


# EXAMPLE
'''
import random
channels=['a','b','c','d']
Nc=len(channels)
Nt=50
start_time=100
M_list=[np.random.rand(Nc,Nc) for i in range(Nt)]
M_list=[1/2*(M_list[t]+M_list[t].T) for t in range(Nt)]
bar_list=[[random.uniform(0,1) for i in range(Nc)] for t in range(Nt)]
conn_win_value=.5

heatplot_barplot_animation2(channels,M_list,bar_list,conn_win_value)
'''


###################################################################
#########  HEATPLOT AND BARPLOT SLIDER ANIMATION  ###############################

def heatplot_barplot_animation_combined(eeg,root,channels,M_list,bar_list,start_time,conn_win_value,xlabel='channel',ylabel='channel',bar_label='Power',title='Coherence and Average Power Spectral Density'):

    num_times=len(M_list)

    #eeg.canvas_frame.destroy()
    #plot_window = Frame(root) #
    plot_window=Toplevel(bg="lightgray")
    plot_window.geometry('900x900') #first number is number of columns
    plot_window.wm_title(title)
    plot_window.attributes('-topmost', 'true')

    fig=plt.Figure()
    canvas = FigureCanvasTkAgg(fig, master=plot_window)
    canvas.draw()
    canvas.get_tk_widget().pack(side=TOP,fill=BOTH,expand=1)

    ax0=fig.add_subplot(211)
    ax1=fig.add_subplot(212)
    ax0.invert_yaxis()


    fig.subplots_adjust(left=.09, bottom=.2, right=None, top=.9, wspace=.2, hspace=.2)
    ax_time=fig.add_axes([0.15, 0.1, 0.65, 0.03]) # axis for slider


    #slider_labels=[j*conn_win_value +eeg.start_time for j in range(num_times)]
    #s_time = Slider(ax_time, 'Time',valinit=0,valmin=0,valmax=(num_times*conn_win_value),valstep=(conn_win_value),dragging=False)
    s_time = Slider(ax_time, 'Time',valinit=start_time,valmin=start_time,valmax=(start_time+num_times*conn_win_value),valstep=(conn_win_value),dragging=False)


    def update_graph(val):
        #print('s_time is *************** '+str(s_time.val))
        #i=int(s_time.val/conn_win_value)
        i=max(1,int((s_time.val-start_time)/conn_win_value) )  # THIS THROWS NEGATIVE VALUES!!!!!!
        #print('i is -------------   '+str(i))
        ax0.cla
        heatmap=ax0.pcolormesh(M_list[i-1],vmin=0, vmax=1, cmap='coolwarm') #, aspect='auto')
        #print('heatmap plotted **************')
        #heatmap=sns.heatmap(ax = ax0, data = M_list[i-1], cmap = "coolwarm")


        ax0.set_xticks([.5 + i for i in range(len(channels))])
        ax0.set_xticklabels(channels,fontsize=font_size(channels))
        ax0.set_yticks([.5 + i for i in range(len(channels))])
        ax0.set_yticklabels(channels,fontsize=font_size(channels),rotation=0)

        ax0.set_xlabel(xlabel,fontsize=14)
        ax0.xaxis.set_label_position('top')
        ax0.set_ylabel(ylabel,fontsize=14)


        ax0_divider = make_axes_locatable(ax0)
        cax0 = ax0_divider.append_axes('right', size='7%', pad='2%')
        cb = fig.colorbar(heatmap, cax=cax0, orientation='vertical')

        ax1.cla()
        ax1.bar(channels,bar_list[i-1])
        ax1.set_ylim(0,  max(max(bar_list)) )
        ax1.tick_params(axis='both', labelsize=font_size(channels))
        ax1.set_ylabel(bar_label,fontsize=14)


        fig.suptitle('Time '+str(np.round(s_time.val,2))+ ' to '+str(np.round(s_time.val+conn_win_value,2))+' sec.')
        fig.canvas.draw_idle()


    s_time.on_changed(update_graph)
    s_time.set_val(start_time)
    return s_time

############  EXAMPLE ###############################

'''
import random
root=Tk()
root.title('Main Window')
root.geometry('1000x1000')
eeg=0

channels=['a','b','c','d']
Nc=len(channels)
Nt=15
start_time=100
M_list=[np.random.rand(Nc,Nc) for i in range(Nt)]
M_list=[1/2*(M_list[t]+M_list[t].T) for t in range(Nt)]
bar_list=[[random.uniform(0,1) for i in range(Nc)] for t in range(Nt)]
conn_win_value=.5

heatplot_barplot_animation_combined(eeg,root,channels,M_list,bar_list,start_time,conn_win_value,title='Coherence and Power Spectral Density')

root.mainloop()
'''

###########################################################################
############# SCROLLING  CONFIGURATION MATRIX VIEWER--USEFUL FOR SCROLLING THROUGH CONFIGURATION MATRIX

def scrolling_configuration_matrix_viewer(eeg,M,channels,start_time,conn_win_value,xlabel,ylabel,title):  # include eeg and replace start_time below with eeg.start_time
    # M is a matrix, with each column corresponding to a multiple of conn_win_value, e.g. column 3 corresponds to 3*conn_win_value
    # As we scroll through the matrix num_col=10 columns at a time, time increases by conn_win_value*num_col

    plot_window = Toplevel(bg="lightgray")
    plot_window.geometry('1400x900')
    plot_window.wm_title(title)
    plot_window.attributes('-topmost', 'true')


    fig, ax = plt.subplots()
    canvas = FigureCanvasTkAgg(fig, master=plot_window)
    canvas.draw()
    canvas.get_tk_widget().pack(side=TOP,fill=BOTH,expand=1)

    plt.subplots_adjust(left=0.25, bottom=.2, right=None, top=.9, wspace=.2, hspace=.2)
    ax_time=fig.add_axes([0.25, 0.1, 0.65, 0.03])
    ax_divider = make_axes_locatable(ax)

    cax = ax_divider.append_axes('right', size='7%', pad='2%')

    num_col=10
    channel_pairs=list_channel_pairs(channels)
    ax.xaxis.set_major_locator(ticker.MaxNLocator(num_col))
    #ax.invert_yaxis


    spos=Slider(ax_time,'Elapsed time',valinit=0,valmin=0,valmax=M.shape[1]*conn_win_value-conn_win_value*num_col,valstep=conn_win_value)
    def update_graph(val):
            # suppose conn_win_value=.5, M has 300 columns,num_col=10; then valstep=5; valmax=145
            start=int(spos.val/conn_win_value)
            stop=start+num_col
            print('triples ************')
            print([spos.val,start,stop])
            ax.cla
            heatmap=ax.pcolormesh(M[:,start:stop],vmin=0, vmax=1, cmap='coolwarm')#, aspect='auto',extent=[0,num_col*conn_win_value,M.shape[0],0])
            print('configuration matrix plotted')
            cb = fig.colorbar(heatmap, cax=cax, orientation='vertical')
            ax_time.set_xlabel(xlabel,fontsize=14)
            ax.set_ylabel(ylabel,fontsize=14)
            ax.set_title(title,fontsize=14)
            ticks=ax.get_xticks()
            xlabels=list(np.round(np.linspace(start_time+spos.val,start_time+spos.val+conn_win_value*num_col,len(ticks)),2))
            ax.set_xticklabels(xlabels)
            if len(channel_pairs)>25:
                ax.set_yticks([])
            else:
                ax.set_yticks(np.arange(.5,.5+len(channel_pairs),1))
                ax.set_yticklabels(channel_pairs,fontsize= font_size(channels))



    spos.on_changed(update_graph)
    spos.set_val(0)
    return spos


'''Example
root=Tk()

M=np.random.rand(4,300)
channels=['A','B','C','D']
conn_win_value=.25
xlabel='time (sec)'
ylabel='channel'
title='matrix scroller'
scrolling_matrix_viewer(M,channels,conn_win_value,xlabel,ylabel,title)
root.mainloop()
'''


###########################################################################################
##################### SCROLLING_CH_TIME_HFO_MATRIX #############################
# useful for the heatplot showing frequency in terms of time and channel

def scrolling_hfo_time_channel_viewer(M,channels,fs,xlabel,ylabel,title,yticks=True):

    plot_window = Toplevel(bg="lightgray")
    plot_window.geometry('1400x900')
    plot_window.wm_title('')
    plot_window.attributes('-topmost', 'true')

    fig, ax = plt.subplots()
    canvas = FigureCanvasTkAgg(fig, master=plot_window)
    canvas.draw()
    canvas.get_tk_widget().pack(side=TOP,fill=BOTH,expand=1)

    ax.xaxis.set_major_locator(ticker.MaxNLocator(10))
    ax.invert_yaxis

    fig.subplots_adjust(left=.09, bottom=.2, right=None, top=.9, wspace=.2, hspace=.2)
    #plt.subplots_adjust(left=0.25, bottom=.2, right=None, top=.9, wspace=.2, hspace=.2)
    ax_time=fig.add_axes([0.15, 0.1, 0.65, 0.03])
    #ax_time=fig.add_axes([0.25, 0.1, 0.65, 0.03])
    ax_divider = make_axes_locatable(ax)
    cax = ax_divider.append_axes('right', size='7%', pad='2%')

    # number of seconds slider advances; fs*win_size is the number of columns of M
    win_size=10

    spos=Slider(ax_time,'Time',valinit=0,valmin=0,valmax=int(M.shape[1]/fs-win_size),valstep=win_size,dragging=False)
    def update_graph(val):
            # suppose conn_win_value=.5, M has 300 columns,num_col=10; then valstep=5; valmax=145
            start=int(spos.val*fs)
            stop=start+win_size*fs
            ax.cla
            heatmap=ax.imshow(M[:,start:stop],vmin=0, vmax=np.amax(M), cmap='coolwarm', aspect='auto' ,extent=[0,win_size*fs,M.shape[0],0])
            cb = fig.colorbar(heatmap, cax=cax, orientation='vertical')
            ax_time.set_xlabel(xlabel)
            ax.set_ylabel(ylabel,fontsize=10)
            ax.set_title(title)
            ticks=ax.get_xticks()
            xlabels=list(np.round(np.linspace(spos.val,spos.val+win_size,len(ticks)),2))
            ax.set_xticklabels(xlabels)
            if yticks:
                ax.set_yticks(np.arange(.5,.5+len(channels),1))
                ax.set_yticklabels(channels,fontsize= font_size(channels))
            else:
                ax.set_yticks(np.arange(.5,.5+M.shape[0],1))
                ax.set_yticklabels([])


    spos.on_changed(update_graph)
    spos.set_val(0)







###########################################################################################
##################### SCROLLING_STACKED_MATRIX_SEQUENCE_VIEWER #############################
# useful for creating an animation of mutual information matrices above transfer entropy matrices


def scrolling_stacked_matrix_sequence_viewer(root,M_list,N_list,channels,conn_win_value):
    plot_window = Toplevel(root,bg='lightgray')
    plot_window.geometry('1400x900')
    plot_window.wm_title('')
    plot_window.attributes('-topmost', 'true')

    fig=plt.Figure()

    canvas = FigureCanvasTkAgg(fig, master=plot_window)
    canvas.draw()
    canvas.get_tk_widget().pack(side=TOP,fill=BOTH,expand=1)


    #ax,fig=plt.subplots(2)
    ax0=fig.add_subplot(211)
    ax1=fig.add_subplot(212)

    ax0.invert_yaxis
    ax1.invert_yaxis

    fig.subplots_adjust(left=.09, bottom=.2, right=None, top=.9, wspace=.2, hspace=.2)
    Nt=len(M_list)
    ax_time=fig.add_axes([0.15, 0.1, 0.65, 0.03]) # axis for slider

    spos = Slider(ax_time, '',valinit=0,valmin=0,valmax=int(Nt*conn_win_value)-conn_win_value,valstep=conn_win_value,dragging=False)

    # add colorbars to right of animation
    ax0_divider = make_axes_locatable(ax0)
    cax0 = ax0_divider.append_axes('right', size='7%', pad='2%')
    ax1_divider = make_axes_locatable(ax1)
    cax1 = ax1_divider.append_axes('right', size='7%', pad='2%')

    def update_graph(val):
            t=int(spos.val/conn_win_value)
            if t<Nt:  # was t<=Nt
               ax0.cla()
               ax1.cla()
               Nc=M_list[t].shape[0]
               heatmap0=ax0.imshow(M_list[t],vmin=0, vmax=1, cmap='coolwarm',
               aspect='auto',extent=[0,Nc,Nc,0])
               cb0 = fig.colorbar(heatmap0, cax=cax0, orientation='vertical')

               heatmap1=ax1.imshow(N_list[t],vmin=0, vmax=1, cmap='coolwarm' ,aspect='auto',extent=[0,Nc,Nc,0])
               cb1 = fig.colorbar(heatmap1, cax=cax1, orientation='vertical')

               ax_time.set_xlabel('time (sec)',fontsize=font_size(channels))
               ax0.set_xlabel('Mutual Information',fontsize=font_size(channels))
               ax0.xaxis.set_label_position('top')

               ax0.set_xticks(np.arange(.5,.5+len(channels),1))
               ax0.set_xticklabels(channels,fontsize=font_size(channels),rotation = 45)
               ax0.set_yticks(np.arange(.5,.5+len(channels),1))
               ax0.set_yticklabels(channels,fontsize=font_size(channels),rotation = 45)

               ax1.set_xlabel('Transfer Entropy (sending)',fontsize=font_size(channels),labelpad=7)
               ax1.xaxis.set_label_position('top')
               ax1.set_ylabel('receiving',fontsize=font_size(channels))


               ax1.set_xticks(np.arange(.5,.5+len(channels),1))
               ax1.set_xticklabels(channels,fontsize=font_size(channels),rotation = 45)
               ax1.set_yticks(np.arange(.5,.5+len(channels),1))
               ax1.set_yticklabels(channels,fontsize=font_size(channels),rotation = 45)


    spos.on_changed(update_graph)
    spos.set_val(0)
    return spos


''' Example
root=Tk()

conn_win_value=.25
M=[np.random.rand(10,10) for t in range(100)]
N=[np.random.rand(10,10) for t in range(100)]
channels=['A','B','C','D','E','F','G','H','I','J']
spos=scrolling_stacked_matrix_sequence_viewer(root,M,N,channels,conn_win_value)

root.mainloop()
'''




############### Player Class ############################
########################################################

class Player(FuncAnimation):
    def __init__(self, fig, func, frames=None, init_func=None, fargs=None,save_count=None, mini=0, maxi=100, pos=(0.125, 0.92), **kwargs):
        self.i = 0
        self.min=mini
        self.max=maxi
        self.runs = True
        self.forwards = True

        self.fig = fig
        self.func = func
        self.setup(pos)
        FuncAnimation.__init__(self,self.fig, self.func, frames=self.play(),
                                           init_func=init_func, fargs=fargs,
                                           save_count=save_count,interval=500, **kwargs )

    def play(self):
        while self.runs:
            self.i = self.i+self.forwards-(not self.forwards)
            if self.i > self.min and self.i < self.max:
                yield self.i
            else:
                self.stop()
                yield self.i

    def start(self):
        if self.i==self.max:
            self.i=0
        self.runs=True
        self.event_source.start()

    def stop(self, event=None):
        self.runs = False
        self.event_source.stop()

    def forward(self, event=None):
        self.forwards = True
        self.start()

    def backward(self, event=None):
        self.forwards = False
        self.start()

    def oneforward(self, event=None):
        if self.i==self.max:
            self.i=0
        self.forwards = True
        self.onestep()
    def onebackward(self, event=None):
        self.forwards = False
        self.onestep()


    def onestep(self):
        if self.i > self.min and self.i < self.max:
            self.i = self.i+self.forwards-(not self.forwards)
        elif self.i == self.min and self.forwards:
            self.i+=1
        elif self.i == self.max and not self.forwards:
            self.i-=1
        self.func(self.i)
        self.fig.canvas.draw_idle()



    def setup(self, pos):
        #playerax = self.fig.add_axes([pos[0],pos[1], 0.22, 0.04])
        playerax = self.fig.add_axes([0.4, 0.92, 0.22, 0.03])
        # left, bottom, width, height


        divider = mpl_toolkits.axes_grid1.make_axes_locatable(playerax)
        bax = divider.append_axes("right", size="80%", pad=0.05)
        sax = divider.append_axes("right", size="80%", pad=0.05)
        fax = divider.append_axes("right", size="80%", pad=0.05)
        ofax = divider.append_axes("right", size="100%", pad=0.05)
        self.button_oneback = matplotlib.widgets.Button(playerax , label=u'$\u29CF$')
        self.button_back = matplotlib.widgets.Button(bax, label=u'$\u25C0$')
        self.button_stop = matplotlib.widgets.Button(sax, label=u'$\u25A0$')
        self.button_forward = matplotlib.widgets.Button(fax, label=u'$\u25B6$')
        self.button_oneforward = matplotlib.widgets.Button(ofax, label=u'$\u29D0$')
        self.button_oneback.on_clicked(self.onebackward)
        self.button_back.on_clicked(self.backward)
        self.button_stop.on_clicked(self.stop)
        self.button_forward.on_clicked(self.forward)
        self.button_oneforward.on_clicked(self.oneforward)




###################################################################
#########  HEATPLOT AND BARPLOT PLAYER ANIMATION VERSION II ###############################

def heatplot_barplot_animation_combined2(eeg,root,channels,M_list,bar_list,bar_list_max,start_time,
                                         conn_win_value,xlabel='channel',ylabel='channel',barlabel='Avg. Power Density (mv/hz)',title='Coherence and Average Power Spectral Density'):
    plot_window = Toplevel(bg="lightgray")
    plot_window.geometry('1400x900')
    plot_window.wm_title(title)
    plot_window.attributes('-topmost', 'true')


    fig, ax = plt.subplots(2)

    canvas = FigureCanvasTkAgg(fig, master=plot_window)
    canvas.draw()
    canvas.get_tk_widget().pack(side=TOP,fill=BOTH,expand=1)

    ax[0].invert_yaxis()

    ax[0].set_xticks([.5 + i for i in range(len(channels))])
    ax[0].set_xticklabels(channels,fontsize=font_size(channels))
    ax[0].set_yticks([.5 + i for i in range(len(channels))])
    ax[0].set_yticklabels(channels,fontsize=font_size(channels),rotation=0)
    ax[0].set_xlabel(xlabel,fontsize=14)
    if xlabel=='Sending':
        ax[0].xaxis.set_label_position('top')
    ax[0].set_ylabel(ylabel,fontsize=14)

    def update(i):
        print('bar list in update ######################## with i-1 equal to '+str(i-1))
        print(np.round(bar_list[i],13))

        heatmap=ax[0].pcolormesh(M_list[i],vmin=0, vmax=1, cmap='coolwarm')
        ax[1].cla()
        ax[1].bar(channels,bar_list[i],color='blue')
        ax[1].set_ylim(0,  bar_list_max )
        ax[1].tick_params(axis='both', labelsize=font_size(channels))
        bar_label=barlabel
        ax[1].set_ylabel(bar_label,fontsize=14)

        ax0_divider = make_axes_locatable(ax[0])
        cax0 = ax0_divider.append_axes('right', size='7%', pad='2%')
        cb = fig.colorbar(heatmap, cax=cax0, orientation='vertical')
        if i==len(M_list):
            print('done')

        if i<len(M_list):
            fig.suptitle('Frame '+str(i+1)+' of '+str(len(M_list))+', Time: '+str(np.round(  start_time+i*conn_win_value   ,3))+ ' to '+str(np.round(     start_time+(i+1)*conn_win_value   ,3)))
    ani=Player(fig,update,maxi=len(M_list)-1)



###########################################################################
############# SCROLLING  CONFIGURATION MATRIX VIEWER--VERSION 2

def scrolling_configuration_matrix_viewer2(eeg,M,channels,start_time,conn_win_value):  # include eeg and replace start_time below with eeg.start_time
    # M is a matrix, with each column corresponding to a multiple of conn_win_value, e.g. column 3 corresponds to 3*conn_win_value
    # As we scroll through the matrix num_col=10 columns at a time, time increases by conn_win_value*num_col

    plot_window = Toplevel(bg="lightgray")
    plot_window.geometry('1200x900')
    plot_window.wm_title('')
    plot_window.attributes('-topmost', 'true')

    fig, ax = plt.subplots()

    ax.invert_yaxis
    channel_pairs=list_channel_pairs(channels)

    if len(channel_pairs)>40:
        ax.set_ylabel('channel pairs '+channel_pairs[0]+'  '+channel_pairs[1] +'  ....  '+channel_pairs[-1],fontsize=14)
        ax.set_yticks([])

    else:
        ax.set_ylabel('channel pair',fontsize=14)
        ax.set_yticks(np.arange(.5,.5+len(channel_pairs),1))
        ax.set_yticklabels(list(reversed(channel_pairs)),fontsize= font_size(channel_pairs))

    #plt.subplots_adjust(left=0.25, bottom=.2, right=None, top=.9, wspace=.2, hspace=.2)

    ax_divider = make_axes_locatable(ax)
    cax = ax_divider.append_axes('right', size='7%', pad='2%')

    canvas = FigureCanvasTkAgg(fig, master=plot_window)
    canvas.draw()
    canvas.get_tk_widget().pack(side=TOP,fill=BOTH,expand=1)

    num_col=10
    ax.xaxis.set_major_locator(ticker.MaxNLocator(num_col))

    def update(i):
            # suppose conn_win_value=.5, M has 300 columns,num_col=10; then valstep=5; valmax=145
            heatmap=ax.pcolormesh(M[:,i:i+num_col],vmin=0, vmax=1, cmap='coolwarm')#, aspect='auto',extent=[0,num_col*conn_win_value,M.shape[0],0])
            cb = fig.colorbar(heatmap, cax=cax, orientation='vertical')
            ax.set_xlabel('time (sec.)',fontsize=14)
            ticks=ax.get_xticks()
            xlabels=[np.round(start_time+conn_win_value*(i+tick),3) for tick in ticks]
            #xlabels=list(np.arange(start_time+i,start_time+i*conn_win_value*num_col
            #xlabels=list(np.round(np.arange(start_time,start_time+i+conn_win_value*num_col,len(ticks)),conn_win_value))

            ax.set_xticklabels(xlabels)

            if len(channel_pairs)>40:
                ax.set_ylabel('channel pairs '+channel_pairs[0]+'  '+channel_pairs[1] +'  ....  '+channel_pairs[-1],fontsize=14)
                ax.set_yticks([])

            else:
                ax.set_ylabel('channel pair',fontsize=14)
                ax.set_yticks(np.arange(.5,.5+len(channel_pairs),1))
                ax.set_yticklabels(list(reversed(channel_pairs)),fontsize= font_size(channel_pairs))


            fig.suptitle('Frame '+str(i+1)+' of '+str(M.shape[1]-num_col+1)+', Coherence Values from Time: '
                +str(np.round(xlabels[0],3))+' to ' +str(np.round(xlabels[-1],3))+' sec.')

                         #+str(np.round(  start_time+i*conn_win_value*num_col   ,3))+ ' to '+str(np.round( start_time+(i+1)*conn_win_value*num_col  ,3)))


    ani=Player(fig,update,maxi=M.shape[1]-num_col)


#Example
'''
root=Tk()

eeg=0
M=np.random.rand(6,20)
channels=['A','B','C','D']
start_time=80
conn_win_value=.5

scrolling_configuration_matrix_viewer2(eeg,M,channels,start_time,conn_win_value)
root.mainloop()
'''




###########################################################################
############# SCROLLING  HFO Time Channel Frequence Matrix Viewer--VERSION 2


def scrolling_hfo_time_channel_viewer2(M,channels,fs):

    plot_window = Toplevel(bg="lightgray")
    plot_window.geometry('1400x900')
    plot_window.wm_title('')
    plot_window.attributes('-topmost', 'true')

    fig, ax = plt.subplots()
    canvas = FigureCanvasTkAgg(fig, master=plot_window)
    canvas.draw()
    canvas.get_tk_widget().pack(side=TOP,fill=BOTH,expand=1)

    ax.xaxis.set_major_locator(ticker.MaxNLocator(10))
    ax.invert_yaxis


    ax.set_ylabel('channel',fontsize=14)
    ax.set_yticks(np.arange(.5,.5+len(channels),1))
    ax.set_yticklabels(list(reversed(channels)),fontsize= font_size(channels))

    plt.subplots_adjust(left=0.25, bottom=.2, right=None, top=.9, wspace=.2, hspace=.2)

    ax_divider = make_axes_locatable(ax)
    cax = ax_divider.append_axes('right', size='7%', pad='2%')

    canvas = FigureCanvasTkAgg(fig, master=plot_window)
    canvas.draw()
    canvas.get_tk_widget().pack(side=TOP,fill=BOTH,expand=1)


    num_col=10
    #ax.xaxis.set_major_locator(ticker.MaxNLocator(num_col))

    def update(i):
            print('i ================ '+str(i))
            heatmap=ax.pcolormesh(M[:,i:i+num_col],vmin=0, vmax=1, cmap='coolwarm')#, aspect='auto',extent=[0,num_col*conn_win_value,M.shape[0],0])
            cb = fig.colorbar(heatmap, cax=cax, orientation='vertical')
            ax.set_ylabel('channel',fontsize=14)
            ax.set_xlabel('time (sec.)',fontsize=14)
             #ticks=ax.get_xticks()
             #xlabels=[np.round(start_time+conn_win_value*(i+tick),3) for tick in ticks]
             #ax.set_xticklabels(xlabels)
             #ax.set_yticks(np.arange(.5,.5+len(channel_pairs),1))
            #ax.set_yticklabels(list(reversed(channels)),fontsize= font_size(channels))
            fig.suptitle('Frame '+str(i+1)) #+' of '+str(M.shape[1]-num_col+1)+', Coherence Values from Time: '
            #    +str(np.round(xlabels[0],3))+' to ' +str(np.round(xlabels[-1],3))+' sec.')


    ani=Player(fig,update,maxi=M.shape[1]-num_col)



################ BAR PLOT WITH SLIDER, WHERE BAR LABELS ARE CHANNELS AND WE ADVANCE THROUGH THE CHANNNELS
################ AS SLIDER ADVANCES

def bar_plot_with_slider(Y,channels,num_bars=8,title='HFO Counts',sort=False):

    if sort:
        zipped_lists=zip(Y,channels)
        sorted_values=sorted(zipped_lists,reverse=True)
        channels = [element for _, element in sorted_values]
        Y.sort(reverse=True)
        Y=[y for y in Y]

    bar_window = Toplevel()
    bar_window.configure(bg='lightgrey')
    bar_window.geometry('1400x900')
    bar_window.wm_title(title)
    bar_window.attributes('-topmost', 'true')


    fig = plt.Figure()
    canvas = FigureCanvasTkAgg(fig, bar_window)
    canvas.draw()
    canvas.get_tk_widget().pack(side=TOP, fill=BOTH, expand=1)

    M=max(Y)
    N=num_bars

    ax=fig.add_subplot(111)
    ax.axis([0, N, 0,M])

    ax.set_xticks(range(len(channels)))
    ax.set_xticklabels(channels,fontsize=12)
    fig.subplots_adjust(bottom=0.25)

    #if len(channels)<=10:
    #    X=range(len(channels))
    #    ax.bar(X,Y,width=0.7,align='center',color='green',ecolor='black')
    #    return

    #else:

    X=range(len(channels))
    ax.bar(X,Y,width=0.7,align='center',color='green',ecolor='black')

    if len(channels)<=10:
        ax.axis([-1/2, len(channels), 0,M+1])


    # Add animation slider only if more than 10 channels:

    if len(channels)>10:
        ax_time = fig.add_axes([0.12, 0.1, 0.78, 0.03])
        s_time = Slider(ax_time, 'Channels', 0, len(X)-N, valinit=0,valstep=1)

        def update(val):
            N=num_bars
            pos = s_time.val
            ax.axis([pos-1/2, pos+N-1/2, 0,M+1])
            fig.canvas.draw_idle()

        s_time.on_changed(update)
        s_time.set_val(0)
