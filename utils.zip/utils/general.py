import numpy as np
import mne as mn
from scipy import signal

import mne
mne.viz.set_browser_backend('matplotlib')

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

import matplotlib.backends.backend_tkagg as tkagg
import matplotlib.ticker as ticker
import matplotlib
matplotlib.use('TkAgg')

from matplotlib import pyplot as plt
from matplotlib.figure import Figure
from matplotlib.widgets import Slider

from tkinter import Tk, IntVar,Frame,Label, Button, Entry,Label, Checkbutton,BooleanVar,filedialog,StringVar,messagebox,ttk,DoubleVar,Frame,LEFT,TOP,RIGHT,BOTTOM,BOTH,INSERT,END,Menu,Toplevel,PhotoImage
from tkinter import font as tkFont
from tkinter.ttk import Progressbar
import tkinter.scrolledtext as st
from tkhtmlview import HTMLLabel,HTMLScrolledText
import webbrowser

from functools import partial

#from preprocessing_11_28 import find_channel_subset_annotations

from mne import create_info
from mne.io import RawArray

import os
import re


################ AUXILLIARY FUNCTION TO DETERMINE CHANNEL LABEL PLOT SIZE DEPENDENDING
################## NUMBER OF CHANNELS BEING SELECTED FOR PLOT

def font_size(channels):
    if len(channels)>60:
        return 6
    else:
        if len(channels)>=40:
            return 8
        else:
            if len(channels)>=30:
                return 10
            else:
                return 12


################ AUXILLIARY FUNCTION TO LIST ALL CHANNEL PAIRS FROM LIST OF CHANNELS,
################## FOR EXAMPLE IF Channels=['a','b','c'], OUTPUT IS ['ab','ac','bc']
###############  USEFUL FOR VIEWING COHERENCE CONFIGUREATION MATRIX

def list_channel_pairs(channels):
    Nc=len(channels)
    channel_pairs=[]
    for i in range(Nc):
        for j in np.arange(i+1,Nc,1):
            channel_pairs.append(channels[i]+'-'+channels[j])
    return channel_pairs





############ AUXILLIARY FUNCTION TO GET DATA MATRIX, CHANNELS, SAMPLING FREQUENCY FROM
############ RAW FILE AND USING CHOSEN TIME WINDOW FROM HFO OPTIONS

def get_data(eeg,raw,fig,start,end):

    bads=fig.mne.info['bads'] # get current set of bad channels from figure
    channels=fig.mne.info["ch_names"] # get all channels from fig = eeg.raw.info['ch_names']
    #to_drop=list(set(channels).intersection(set(bads))) #
    #channels=list(set(channels).difference(set(bads)))
    channels=[ch for ch in eeg.raw_orig.info["ch_names"] if ch in set(channels)-set(bads)]  # change ch in channels to ch in eeg.raw_orig channels

    #print('channels inside get info ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^')
    #print(channels)
    # dropped on 5/3        eeg.raw=eeg.raw_orig.pick_channels(channels)

    raw_new=eeg.raw_orig.copy().pick_channels(channels)

    #eeg.raw.drop_channels(to_drop)
    #channels=raw.info["ch_names"]
    fs=int(eeg.raw.info['sfreq'])
    data,times=raw_new[:,:]
    # dropped on 5/2:        data,times=eeg.raw[:,:]


    X=data.T
    X=X[int(fs*start):int(fs*end),:]
    return X,fs,channels



########### SAVE DATA MATRIX AND CHANNELS INTO MNE .fif OBJECT
def create_fif(X,channels,fs, file_name):
    '''
    Generate and save fif file created from data matrix.
    Args:
        X : data matrix in form num_channels-by-num_times
        channels
        sampling frequency
        filename: string ending with _.fif, e.g. 'myfile_eeg.fif'
    Returns:
       .fif created using above info
    '''

    info = create_info(sfreq=fs, ch_names=channels,ch_types='seeg')
    raw = RawArray(data=X, info=info)
    raw.save(file_name,overwrite=True)

############# fif_reader) ####################

# file name must have specified suffix, e.g.
# file_name='/Users/fishbacp/Desktop/Python_May_2021/simulated_data/pdc_mvar_five_signals_eeg.fif'

def fif_reader(file_name):
    raw=mn.io.read_raw_fif(file_name,preload=True)
    fs=raw.info['sfreq']
    channels=raw.info['ch_names']
    data,times=raw[:,:]
    X=data.T
    return raw,X,fs,channels


######### REPLOT #############################################

def replot(root,eeg): # plots both good and bad channels using eeg.plot_start and eeg.plot_duration
    raw_temp=eeg.raw.copy()
    bads=eeg.fig.mne.info['bads']
    raw_temp.info["bads"]=bads
    eeg.raw=raw_temp
    eeg.canvas_frame.destroy()
    eeg.plot_canvas()



########## PLOT SELECTED CHANNELS ON ROOT WINDOW ###################
def plot_selected(root,eeg,annotations=False):

    if set(eeg.fig.mne.info['bads'])==set(eeg.channels):
         messagebox.showerror("Error","No channels selected!!")
         return

    # eeg.canvas_frame.destroy()

    bads=eeg.fig.mne.info['bads'] # get current set of bad channels from figure
    channels=eeg.fig.mne.info["ch_names"] # get all channels from fig = eeg.raw.info['ch_names']
    #channels=list(set(channels).difference(set(bads)))

    channels=[ch for ch in channels if ch in set(channels)-set(bads)]

    # Pressing + stretches plot vertically; makes scale_factor below larger; makes eeg.scalings['eeg'] value smaller; stretches curve in replot;

    #print(eeg.fig.mne.plot_scaler)

    # eeg.plot_scale_factor=eeg.fig.mne.scale_factor
    # print(eeg.plot_scale_factor)
    # scalings

    #print(eeg.fig.mne.scale_factor)

    #eeg.scalings=dict({'eeg':.000050*eeg.fig.mne.scale_factor})
    #print(eeg.scalings)

    # eeg.scalings[eeg]=eeg.fig.mne.scale_factor*.000050
    # eeg.scalings=dict(eeg=20e-6*eeg.plot_scale_factor)

    eeg.start_time = eeg.fig.mne.t_start - eeg.fig.mne.first_time
    eeg.end_time = eeg.start_time + eeg.fig.mne.duration

    eeg.plot_start=eeg.start_time
    eeg.plot_duration=eeg.end_time-eeg.start_time

    #print('CHANNELS  BEFORE EEG.RAW RESET ==========================================================')
    #print(eeg.raw.info["ch_names"])
    #print(eeg.raw_orig.info['ch_names'])

    #eeg.raw=eeg.raw.copy().pick_channels(channels)
    raw_temp=eeg.raw_orig.copy()
    eeg.raw=raw_temp.pick_channels(channels) # We decrease size of eeg right here because we've changed the channels!

    #print('CHANNELS  AT END OF REPLOT ==========================================================')

    #print(eeg.raw.info["ch_names"])
    #print(eeg.raw_orig.info['ch_names'])

    eeg.canvas_frame.destroy()

    if annotations:
        eeg.plot_canvas(annotations=True)
    else: eeg.plot_canvas(annotations=False)



''' OLD
    fs=eeg.fs
    raw_temp=eeg.raw.copy()
    bads=eeg.fig.mne.info['bads']
    channels=eeg.fig.mne.info['ch_names'] #eeg.raw.info['ch_names']
    to_drop=list(set(channels).intersection(set(bads)))
    eeg.raw.drop_channels(to_drop)  # eeg.channels is now smaller

    channels=eeg.raw.info['ch_names']

    eeg.start_time = eeg.fig.mne.t_start - eeg.fig.mne.first_time
    eeg.end_time = eeg.start_time + eeg.fig.mne.duration

    eeg.plot_start=eeg.start_time
    eeg.plot_duration=eeg.end_time-eeg.start_time

    if annotations:
        eeg.plot_canvas(annotations=True)
    else: eeg.plot_canvas(annotations=False)
'''

############# POWER SPECTRAL DENSITIES FOR CHANNELS AVERAGED OVER FREQUENCY
############## fmin to fmax

############## data has size num_channels -by -num_times
############### Output is a list of power spectral densities
def PSD(data,channels,fs,fmin,fmax):
    Nc=len(channels)
    PSD_list=[]
    for i in range(Nc):
        freq, PSD = signal.welch(data[i,:], fs, nperseg=len(data[i,:]))
        f1=np.argwhere(freq>=fmin)[0][0]
        f2=np.argwhere(freq>=fmax)[0][0]
        PSD_mean=np.mean(PSD[f1:f2])
        PSD_list.append(PSD_mean)
    return PSD_list


################### LICENSE WINDOW ##################################
####################################################################


def license_window(config_path):
    my_file = open(config_path, "r+")
    content = my_file. read()
    print(content)

    if content=='0':
        info_window=Toplevel()
        info_window.geometry('450x300')
        info_window.wm_title('Software License')
        info_window.attributes('-topmost', 'true')

        def close_window():
            info_window.destroy()

        def update_config():
            my_file = open(config_path, "r+")
            content = my_file.read()
            content=content.replace('0','1')
            with open(config_path, 'w') as file:
                file.write(content)
            close_window()


        close_button=Button(info_window, text="Close",fg='black',bg='white',borderwidth=0,command=close_window)
        close_button.pack(side=BOTTOM,expand=True)

        choice = IntVar()
        choice_box = Checkbutton(info_window, text='Do not show this again at startup.',variable=choice, onvalue=1, offvalue=0, command=update_config)
        choice_box.pack(side=BOTTOM,expand=True)


        L0='<h3 style="color: black; text-align: center">'
        L1='<a rel="license" href="http://creativecommons.org/licenses/by-nc/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc/4.0/88x31.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc/4.0/">Creative Commons Attribution-NonCommercial 4.0 International License.</a>'
        L2='<h4 style="color: black; text-align: left"> '
        L3='<p> This work is distributed as is <u> You are free to: </u></p>'
        L5='1. Share, copy and redistribute the material in any medium or format.<br>'
        L6='2. Adapt, remix, transform, and build upon the material.<br>'
        L7='<p> <u>Under the following terms:</u></p>'
        L8='1. You must give appropriate credit, provide a link to the license, and indicate if changes were made.<br>'
        L9='2. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.<br>'
        L10='3. You may not use the material for commercial purposes.<br>'
        L11='4. You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits. <br> </h4>'
        L12='<p> <h4 style="color: black; text-align: left"> This software makes extensive use of the <a href="https://mne.tools/stable/index.html">MNE-Python,</a> package, copyright 2022,'
        L13='which is licensed under BSD-3-Clause. Please acknowledge the MNE-Python developers should you modify this code for your own purposes. </h4> </p>'

        D1='<h3 style="color: black; text-align: center"><u>Disclaimer</u>'
        D2='<h4 style="color: black; text-align: left">'
        D3='This software is provided <em> as is</em>, for use at users own risk, without warranty of any kind, express or implied. In no event shall the authors or '
        D4='copyright holders be liable for any claim, damages or other liability, whether in an action of contract, tort or otherwise, arising from, out of or in connection '
        D5='with the software or the use or other dealings in the software. </h4>'


        text=L0+L1+L2+L3+L5+L6+L7+L8+L9+L10+L11+L12+L13+D1+D2+D3+D4+D5

        R1='<h3 style="color: black; text-align: center"><u>References</u>'
        R2='<h4 style="color: black; text-align: left">'
        R3='1. Burnos, S., et al, Human Intracranial High Frequency Oscillations (HFOs) Detected by Automatic Time-Frequency Analysis,<em> PLoS ONE </em>, <b>9</b>(4), 2014.<br>'
        R4='2. Dean, C., An Investigation into the Development of a Low Cost, Easy to Use Seizure Analysis Tool, 2020,'
        R5='<a href="https://scholarworks.gvsu.edu/theses/1003">Grand Valley State University Scholarworks</a>.<br>'
        R6='3. Farrel, D., DataExplore: An Application for General Data Analysis in Research and Education, <em>Journal of Open Research Software</em>, <b>4</b>, 2016.<br>'
        R7='4. Gurisko, J., A Quantitative Tool for Identifying the Epileptogenic Zone using Network Connectivity Analysis, 2014, '
        R8='<a href="https://scholarworks.gvsu.edu/theses/712">Grand Valley State University Scholarworks</a> <br>'
        R9='5. Gramfort, A., et al, MEG and EEG data analysis with <a href="https://mne.tools/stable/index.html">MNE-Python,</a>, <em> Frontiers in Neuroscience </em>, <b>7 </b> (267), 1–13, 2013.<br>'
        R10='6. Hagberg, A., et al, Exploring network structure, dynamics, and function using NetworkX, <em>Proceedings of the 7th Python in Science Conference (SciPy2008)</em>,  11–15, 2008.<br>'
        R11='7. Khambhatai, A., et al, Dynamic network drivers of seizure generation,propagation and termination in human epilepsy, <em>PLoS Comput Biology </em>, <b>11</b>(12), 2015. <br>'
        R12='8. Krzemiński D., Kamiński M.,<a href="https://github.com/dokato/connectivipy">Connectivipy</a>, 2022. <br>'
        R13='9. Opsahl, T., et al, Node centrality in weighted networks: Generalizing degree and shortest paths, <em> Social Networks,</em>, <b>32</b>(3),245-251, 2010. <br>'
        R14='10. Staba, R., et al, Quantitative Analysis of High-Frequency Oscillations (80 − 500 Hz) Recorded in Human Epileptic Hippocampus and Entorhinal Cortex,<br>'
        R15='<em>Journal of Neurophysiology</em>, <b>88</b>, 1743–1752, 2002.<br>'
        R16='11. van Mierlo P, et al, Accurate epileptogenic focus localization through time-variant functional connectivity analysis of intracranial electroencephalographicsignals,'
        R17='<em>Neuroimage</em>, <b>56</b>(3), 1122-1133, 2011. <br>'

        text=text+R1+R2+R3+R4+R5+R6+R7+R8+R9+R10+R11+R12+R13+R14+R15+R16+R17


        html_label = HTMLScrolledText(info_window, html=text)
        html_label.pack() #fill="both", expand=True)
        html_label.fit_height()


################### PROGRAM INFO WINDOW ##################################
####################################################################

def program_info_window():
    info_window=Toplevel()
    info_window.geometry('600x450')
    info_window.wm_title('License and Resources')
    info_window.attributes('-topmost', 'true')

    def close_info_window():
        info_window.destroy()

    close_button=Button(info_window, text="Close",fg='black',bg='white',borderwidth=0,command=close_info_window)
    close_button.pack(side=BOTTOM,expand=True)


    L0='<h3 style="color: black; text-align: center">'
    L1='<a rel="license" href="http://creativecommons.org/licenses/by-nc/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc/4.0/88x31.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc/4.0/">Creative Commons Attribution-NonCommercial 4.0 International License.</a>'
    L2='<h4 style="color: black; text-align: left"> '
    L3='<p> This work is distributed as is <u> You are free to: </u></p>'
    L5='1. Share, copy and redistribute the material in any medium or format.<br>'
    L6='2. Adapt, remix, transform, and build upon the material.<br>'
    L7='<p> <u>Under the following terms:</u></p>'
    L8='1. You must give appropriate credit, provide a link to the license, and indicate if changes were made.<br>'
    L9='2. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.<br>'
    L10='3. You may not use the material for commercial purposes.<br>'
    L11='4. You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits. <br> </h4>'
    L12='<p> <h4 style="color: black; text-align: left"> This software makes extensive use of the <a href="https://mne.tools/stable/index.html">MNE-Python,</a> package, copyright 2022,'
    L13='which is licensed under BSD-3-Clause. Please acknowledge the MNE-Python developers should you modify this code for your own purposes. </h4> </p>'

    D1='<h3 style="color: black; text-align: center"><u>Disclaimer</u>'
    D2='<h4 style="color: black; text-align: left">'
    D3='This software is provided <em> as is</em>, for use at users own risk, without warranty of any kind, express or implied. In no event shall the authors or '
    D4='copyright holders be liable for any claim, damages or other liability, whether in an action of contract, tort or otherwise, arising from, out of or in connection '
    D5='with the software or the use or other dealings in the software. </h4>'


    text=L0+L1+L2+L3+L5+L6+L7+L8+L9+L10+L11+L12+L13+D1+D2+D3+D4+D5


    R1='<h3 style="color: black; text-align: center"><u>References</u>'
    R2='<h4 style="color: black; text-align: left">'
    R3='1. Burnos, S., et al, Human Intracranial High Frequency Oscillations (HFOs) Detected by Automatic Time-Frequency Analysis,<em> PLoS ONE </em>, <b>9</b>(4), 2014.<br>'
    R4='2. Dean, C., An Investigation into the Development of a Low Cost, Easy to Use Seizure Analysis Tool, 2020,'
    R5='<a href="https://scholarworks.gvsu.edu/theses/1003">Grand Valley State University Scholarworks</a>.<br>'
    R6='3. Farrel, D., DataExplore: An Application for General Data Analysis in Research and Education, <em>Journal of Open Research Software</em>, <b>4</b>, 2016.<br>'
    R7='4. Gurisko, J., A Quantitative Tool for Identifying the Epileptogenic Zone using Network Connectivity Analysis, 2014, '
    R8='<a href="https://scholarworks.gvsu.edu/theses/712">Grand Valley State University Scholarworks</a> <br>'
    R9='5. Gramfort, A., et al, MEG and EEG data analysis with <a href="https://mne.tools/stable/index.html">MNE-Python,</a>, <em> Frontiers in Neuroscience </em>, <b>7 </b> (267), 1–13, 2013.<br>'
    R10='6. Hagberg, A., et al, Exploring network structure, dynamics, and function using NetworkX, <em>Proceedings of the 7th Python in Science Conference (SciPy2008)</em>,  11–15, 2008.<br>'
    R11='7. Khambhatai, A., et al, Dynamic network drivers of seizure generation,propagation and termination in human epilepsy, <em>PLoS Comput Biology </em>, <b>11</b>(12), 2015. <br>'
    R12='8. Krzemiński D., Kamiński M.,<a href="https://github.com/dokato/connectivipy">Connectivipy</a>, 2022. <br>'
    R13='9. Opsahl, T., et al, Node centrality in weighted networks: Generalizing degree and shortest paths, <em> Social Networks,</em>, <b>32</b>(3),245-251, 2010. <br>'
    R14='10. Staba, R., et al, Quantitative Analysis of High-Frequency Oscillations (80 − 500 Hz) Recorded in Human Epileptic Hippocampus and Entorhinal Cortex,<br>'
    R15='<em>Journal of Neurophysiology</em>, <b>88</b>, 1743–1752, 2002.<br>'
    R16='11. van Mierlo P, et al, Accurate epileptogenic focus localization through time-variant functional connectivity analysis of intracranial electroencephalographicsignals,'
    R17='<em>Neuroimage</em>, <b>56</b>(3), 1122-1133, 2011. <br>'

    text=text+R1+R2+R3+R4+R5+R6+R7+R8+R9+R10+R11+R12+R13+R14+R15+R16+R17


    html_label = HTMLScrolledText(info_window, html=text)
    html_label.pack() #fill="both", expand=True)
    html_label.fit_height()


################### START VIDEO TUTORIAL ##################################
####################################################################
def start_video_tutorial():
    webbrowser.open('https://youtu.be/JkR_1oTGEMY')
